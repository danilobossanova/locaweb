package com.locaweb.model

data class ScheduledEmailPreview(
     val photo: Int,
     val sender: String,
     val subject: String,
     val text: String,
     val time: String,
)
