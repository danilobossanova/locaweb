package com.locaweb.model

data class ReceivedEmailPreview(
    val photo: Int,
    val sender: String,
    val subject: String,
    val text: String,
    val time: String,
    val pinned: Boolean = false,
    val viewed: Boolean = false
)
