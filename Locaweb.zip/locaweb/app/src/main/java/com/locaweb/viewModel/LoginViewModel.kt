package com.locaweb.viewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class LoginViewModel: ViewModel() {
    private val _email = MutableLiveData<String>()
    val email: LiveData<String> = _email

    fun onEmailChange(newEmail: String) {
        _email.value = newEmail.trim()
    }

    private val _pwd = MutableLiveData<String>()
    val pwd: LiveData<String> = _pwd

    fun onPwdChange(newPwd: String) {
        val limitSize = 8

        if (newPwd.length <= limitSize)
        {
            _pwd.value = newPwd.replace(
                regex = Regex(pattern = "[^0-9]"),
                replacement = ""
            )
        }
    }

    private val _emailError = MutableLiveData<Boolean>()
    val emailError: LiveData<Boolean> = _emailError

    fun setEmailError(exp: Boolean)
    {
        _emailError.value = exp
    }

    private val _pwdError = MutableLiveData<Boolean>()
    val pwdError: LiveData<Boolean> = _pwdError

    fun setPwdError(exp: Boolean)
    {
        _pwdError.value = exp
    }
}