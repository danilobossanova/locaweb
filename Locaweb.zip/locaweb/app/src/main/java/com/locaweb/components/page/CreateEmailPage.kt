package com.locaweb.components.page

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.navigation.NavController
import com.locaweb.R
import com.locaweb.components.button.FillButton
import com.locaweb.components.form.Form
import com.locaweb.components.form.Input
import com.locaweb.components.layout.Footer
import com.locaweb.components.text.BoldText
import com.locaweb.components.text.PageTitle
import com.locaweb.ui.theme.Aqua
import com.locaweb.ui.theme.DarkGrey
import com.locaweb.ui.theme.Red
import com.locaweb.ui.theme.White
import com.locaweb.viewModel.CreateEmailViewModel
import kotlinx.coroutines.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun CreateEmailPage(navController: NavController, viewModel: CreateEmailViewModel)
{
    val coroutineScope = rememberCoroutineScope()

    Box(modifier = Modifier.fillMaxSize())
    {
        Column {
            PageTitle(text = "Enviar email")

            Column(
                modifier = Modifier.padding(10.dp)
            ) {
                val addresse by viewModel.addresse.observeAsState(initial = "")
                val subject by viewModel.subject.observeAsState(initial = "")
                val content by viewModel.content.observeAsState(initial = "")
                val forWhen by viewModel.forWhen.observeAsState(initial = "")

                Form {
                    Input(
                        name = "Para",
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email
                        ),
                        placeholder = "Destinatário",
                        value = addresse,
                        onValueChange = {
                            viewModel.onAddresseChange(it)
                        }
                    )
                    Input(
                        name = "Assunto",
                        keyboardOptions = KeyboardOptions(),
                        placeholder = "Assunto do email",
                        value = subject,
                        onValueChange = {
                            viewModel.onSubjectChange(it)
                        }
                    )
                    var isRecording by remember {
                        mutableStateOf(false)
                    }

                    fun putMessage() {
                        coroutineScope.launch {
                            isRecording = true
                            val message = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vel dapibus magna. In sollicitudin ex elementum, malesuada nisi eget, pulvinar augue. Aliquam congue efficitur interdum."
                            val temp_message_chars = mutableListOf<Char>()

                            viewModel.onContentChange("")

                            for (char in message) {
                                temp_message_chars.add(char)
                                delay(40)
                                viewModel.onContentChange(temp_message_chars.joinToString(""))
                            }
                            isRecording = false
                        }
                    }

                    Input(
                        name = "Conteúdo",
                        keyboardOptions = KeyboardOptions(),
                        placeholder = "Escreva aqui",
                        value = content,
                        onValueChange = {
                            viewModel.onContentChange(it)
                        },
                        maxLines = 7
                    )
                    Input(
                        name = "Para quando",
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number
                        ),
                        placeholder = "DD/MM/AAAA",
                        value = forWhen,
                        onValueChange = {
                            viewModel.onForWhenChange(it)
                        },
                    )

                    Button(
                        onClick = {
                            putMessage()
                        },
                        shape = RoundedCornerShape(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        border = BorderStroke(1.dp, if (!isRecording) Aqua else Red),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row {
                            Icon(
                                painter = painterResource(id =if (!isRecording) R.drawable.microphone else R.drawable.stop),
                                contentDescription = "Adicionar arquivos",
                                modifier = Modifier.size(20.dp),
                                tint = if (!isRecording) Aqua else Red
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            BoldText(text = "Transcrever", fontSize = 17.sp)
                        }
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Max)
                    ) {
                        Button(
                            onClick = {},
                            shape = RoundedCornerShape(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            border = BorderStroke(1.dp, Aqua),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row {
                                Icon(
                                    painter = painterResource(id = R.drawable.attach),
                                    contentDescription = "Adicionar arquivos",
                                    modifier = Modifier.size(20.dp),
                                    tint = Aqua
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                BoldText(text = "Arquivos", fontSize = 17.sp)
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Button(
                            onClick = {},
                            shape = RoundedCornerShape(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            border = BorderStroke(1.dp, Aqua),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row {
                                Icon(
                                    painter = painterResource(id = R.drawable.image),
                                    contentDescription = "Adicionar images",
                                    modifier = Modifier.size(20.dp),
                                    tint = Aqua
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                BoldText(text = "Imagens", fontSize = 17.sp)
                            }
                        }
                    }

                    FillButton(
                        onClickAction = {
                                        navController.navigate("sentEmails")
                        },
                        horizontalArrangement = Arrangement.Center,
                        background = Red,
                        contentColor = White
                    ) {
                        BoldText(
                            text = "Enviar",
                            fontSize = 22.sp,
                        )
                    }
                }
            }
        }
        Footer(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(DarkGrey),
            active = 2,
            navController = navController
        )
    }
}