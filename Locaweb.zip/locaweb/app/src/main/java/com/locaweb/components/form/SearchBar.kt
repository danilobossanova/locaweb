package com.locaweb.components.form

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.locaweb.ui.theme.White
import androidx.compose.material3.Icon
import androidx.compose.ui.Alignment
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.sp
import com.locaweb.R
import com.locaweb.components.text.RegularText

@Composable
fun SearchBar()
{
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, White, RoundedCornerShape(5.dp))
            .padding(horizontal = 15.dp, vertical = 10.dp),
    ) {
        RegularText(text = "Buscar emails", fontSize = 17.sp)
        Icon(
            painter = painterResource(R.drawable.search),
            contentDescription = "Buscar emails",
            modifier = Modifier.size(28.dp),
            tint = White
        )
    }
}