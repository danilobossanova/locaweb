package com.locaweb.components.page

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.locaweb.components.button.AddButton
import com.locaweb.components.email.ScheduledEmailPreview
import com.locaweb.components.layout.Footer
import com.locaweb.components.layout.Header
import com.locaweb.components.text.PageTitle
import com.locaweb.repository.getAllScheduledEmailPreview
import com.locaweb.ui.theme.DarkGrey

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ScheduledEmailsPage(navController: NavController, day: String?)
{
    Box(modifier = Modifier.fillMaxSize())
    {
        LazyColumn {
            stickyHeader {
                Header(navController)
                PageTitle(text = "Programados para o dia $day")
            }
            items(getAllScheduledEmailPreview())
            {
                ScheduledEmailPreview(
                    it,
                    onClickAction = {
                        navController.navigate("scheduledEmail")
                    }
                )
            }
        }
        AddButton(
            onClickAction = {
                navController.navigate("createEmail")
            },
            modifier = Modifier
                .padding(20.dp)
                .align(Alignment.BottomEnd)
                .offset(y = (-100).dp)
        )
        Footer(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(DarkGrey),
            active = 4,
            navController = navController
        )
    }
}