package com.locaweb.components.page

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.locaweb.R
import com.locaweb.components.image.PersonPhoto
import com.locaweb.components.layout.Footer
import com.locaweb.components.layout.Header
import com.locaweb.components.text.BoldText
import com.locaweb.components.text.PageTitle
import com.locaweb.components.text.RegularText
import com.locaweb.ui.theme.Aqua
import com.locaweb.ui.theme.DarkGrey
import com.locaweb.ui.theme.White

@Composable
fun ReceivedEmailPage(navController: NavController)
{
    Box(modifier = Modifier.fillMaxSize())
    {
        Column {
            Header(navController)
            PageTitle(text = "Título do email")

            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 20.dp))
            {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(.27f)
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        PersonPhoto(photo = R.drawable.person1)
                    }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    ) {
                        BoldText(text = "Rementende da Silva", fontSize = 17.sp)
                        RegularText(text = "Para mim", fontSize = 14.sp)
                    }
                    Column(
                        modifier = Modifier
                            .weight(.3f)
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.End
                    ) {
                        RegularText(text = "15:14", fontSize = 16.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Icon(
                            painter = painterResource(id = R.drawable.filled_star),
                            contentDescription = "Favoritado",
                            modifier = Modifier.size(30.dp),
                            tint = White
                        )
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
                RegularText(
                    text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit.\nAliquam vitae dapibus metus. Curabitur imperdiet eu nulla lobortis tempus. Aliquam vitae lectus sed mi imperdiet sollicitudin eu vel lectus.\n\n - Remetente da Silva",
                    fontSize = 16.sp
                )
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { /*TODO*/ },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Aqua),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = PaddingValues(15.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.reply),
                                contentDescription = "Responder",
                                modifier = Modifier.size(30.dp),
                                tint = Aqua
                            )
                            RegularText(text = "Responder", fontSize = 16.sp)
                        }
                    }
                    Spacer(modifier = Modifier.width(5.dp))
                    Button(
                        onClick = { /*TODO*/ },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Aqua),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = PaddingValues(15.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.share),
                                contentDescription = "Encaminhar",
                                modifier = Modifier.size(30.dp),
                                tint = Aqua
                            )
                            RegularText(text = "Encaminhar", fontSize = 16.sp)
                        }
                    }
                }
            }
        }
        Footer(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(DarkGrey),
            active = 1,
            navController = navController
        )
    }
}