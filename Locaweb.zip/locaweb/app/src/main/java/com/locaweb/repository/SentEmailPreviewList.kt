package com.locaweb.repository

import com.locaweb.R
import com.locaweb.model.SentEmailPreview

fun getAllSentEmailPreview(): List<SentEmailPreview>
{
    return listOf(
        SentEmailPreview(
            photo = R.drawable.person4,
            sender = "João Amoedo",
            subject = "Descritivo IR do meu pai",
            text = "Segue abaixo o descritivo de...",
            time = "12:35",
            viewed = true
        ),
        SentEmailPreview(
            photo = R.drawable.person5,
            sender = "Geraldo Alckmin",
            subject = "Problema em dentadura",
            text = "Obtive problema com a dentadura que..",
            time = "12:10"
        ),
        SentEmailPreview(
            photo = R.drawable.person4,
            sender = "Marina Silva",
            subject = "Encontro sobre sustentabilidade",
            text = "Gostaria de discutir a pauta do...",
            time = "14:00"
        ),
        SentEmailPreview(
            photo = R.drawable.person5,
            sender = "Ciro Gomes",
            subject = "Debate na TV",
            text = "Confirmo minha participação no debate...",
            time = "15:20",
            viewed = true
        ),
        SentEmailPreview(
            photo = R.drawable.person6,
            sender = "Fernando Haddad",
            subject = "Novo imposto",
            text = "Precisamos agendar uma reunião para...",
            time = "09:45",
            viewed = true
        ),
        SentEmailPreview(
            photo = R.drawable.person4,
            sender = "Luciano Huck",
            subject = "Evento beneficente",
            text = "Estou organizando um evento beneficente...",
            time = "11:30"
        ),
        SentEmailPreview(
            photo = R.drawable.person5,
            sender = "Manuela D'Ávila",
            subject = "Palestra sobre igualdade de gênero",
            text = "Gostaria de convidá-lo para minha palestra...",
            time = "10:05",
            viewed = true
        ),
        SentEmailPreview(
            photo = R.drawable.person6,
            sender = "Guilherme Bolos",
            subject = "Projeto social",
            text = "Estamos iniciando um novo projeto social...",
            time = "13:25"
        ),
        SentEmailPreview(
            photo = R.drawable.person5,
            sender = "Ciro Gomes",
            subject = "Debate na TV",
            text = "Confirmo minha participação no debate...",
            time = "15:20",
            viewed = true
        ),
        SentEmailPreview(
            photo = R.drawable.person6,
            sender = "Fernando Haddad",
            subject = "Novo imposto",
            text = "Precisamos agendar uma reunião para...",
            time = "09:45",
            viewed = true
        ),
        SentEmailPreview(
            photo = R.drawable.person4,
            sender = "Luciano Huck",
            subject = "Evento beneficente",
            text = "Estou organizando um evento beneficente...",
            time = "11:30"
        ),
        SentEmailPreview(
            photo = R.drawable.person5,
            sender = "Manuela D'Ávila",
            subject = "Palestra sobre igualdade de gênero",
            text = "Gostaria de convidá-lo para minha palestra...",
            time = "10:05",
            viewed = true
        ),
        SentEmailPreview(
            photo = R.drawable.person6,
            sender = "Guilherme Bolos",
            subject = "Projeto social",
            text = "Estamos iniciando um novo projeto social...",
            time = "13:25"
        )
    )
}