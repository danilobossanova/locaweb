package com.locaweb.viewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class CreateEmailViewModel: ViewModel() {
    private val _addresse = MutableLiveData<String>()
    val addresse: LiveData<String> = _addresse

    fun onAddresseChange(newAddresse: String) {
        _addresse.value = newAddresse.trim()
    }

    private val _subject = MutableLiveData<String>()
    val subject: LiveData<String> = _subject

    fun onSubjectChange(newSubject: String) {
        _subject.value = newSubject.trim()
    }

    private val _content = MutableLiveData<String>()
    val content: LiveData<String> = _content

    fun onContentChange(newContent: String) {
        _content.value = newContent.trim()
    }

    val currentDate = LocalDate.now()
    val formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    private val _forWhen = MutableLiveData<String>(currentDate.format(formatter))
    val forWhen: LiveData<String> = _forWhen

    fun onForWhenChange(newForWhen: String) {
        _forWhen.value = applyDateMask(newForWhen.trim())
    }

    private fun applyDateMask(input: String): String {
        val cleaned = input.replace(Regex("[^0-9]"), "")
        val sb = StringBuilder()

        for (i in cleaned.indices) {
            when (i) {
                2, 4 -> sb.append("/")
            }
            if (i < 8) {
                sb.append(cleaned[i])
            }
        }

        return sb.toString()
    }
}