package com.locaweb.model

data class SentEmailPreview(
    val photo: Int,
    val sender: String,
    val subject: String,
    val text: String,
    val time: String,
    val viewed: Boolean = false
)
