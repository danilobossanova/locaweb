package com.locaweb.components.image

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.locaweb.R

@Composable
fun PersonPhoto(photo: Int)
{
    Image(
        painter = painterResource(id = photo),
        contentDescription = "logo",
        modifier = Modifier.size(50.dp).clip(RoundedCornerShape(50.dp))
    )
}