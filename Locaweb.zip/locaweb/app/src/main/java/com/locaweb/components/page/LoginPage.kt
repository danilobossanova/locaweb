package com.locaweb.components.page

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.locaweb.components.button.FillButton
import com.locaweb.components.form.Form
import com.locaweb.components.form.Input
import com.locaweb.ui.theme.White
import com.locaweb.ui.theme.Red
import com.locaweb.components.layout.ColumnCenter
import com.locaweb.components.image.LogoLG
import com.locaweb.components.text.BoldText
import com.locaweb.components.text.RegularText
import com.locaweb.ui.theme.ExtraLightGrey
import com.locaweb.viewModel.LoginViewModel

@Composable
fun LoginPage(navController: NavController, viewModel: LoginViewModel)
{
    Box(modifier = Modifier.fillMaxSize())
    {
        ColumnCenter {
            LogoLG()

            Spacer(modifier = Modifier.height(20.dp))

            RegularText(
                text = "Preencha os dados",
                fontSize = 22.sp,
                color = White
            )

            Spacer(modifier = Modifier.height(15.dp))

            val email by viewModel.email.observeAsState(initial = "")
            val emailError by viewModel.emailError.observeAsState(initial = false)
            val pwd by viewModel.pwd.observeAsState(initial = "")
            val pwdError by viewModel.pwdError.observeAsState(initial = false)

            Form {
                Input(
                    name = "Email",
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Email
                    ),
                    placeholder = "Digite seu Email",
                    value = email,
                    onValueChange = {
                        viewModel.onEmailChange(it)
                    },
                    error = emailError
                )
                if(emailError) {
                    RegularText(
                        text = "O Email é obrigatório",
                        modifier = Modifier.fillMaxWidth(),
                        fontSize = 16.sp,
                        color = Red,
                        textAlign = TextAlign.Right,
                    )
                }

                Input(
                    name = "Senha (8 números)",
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.NumberPassword
                    ),
                    placeholder = "Digite sua senha (8 números)",
                    value = pwd,
                    onValueChange = {
                        viewModel.onPwdChange(it)
                    },
                    visualTransformation = PasswordVisualTransformation(),
                    error = pwdError
                )
                if(pwdError) {
                    RegularText(
                        text = if(pwd.isEmpty()) "A Senha é obrigatória"
                                else "A senha deve ter 8 números",
                        modifier = Modifier.fillMaxWidth(),
                        fontSize = 16.sp,
                        color = Red,
                        textAlign = TextAlign.Right,
                    )
                }
                RegularText(
                    text = "Esqueceu sua senha?",
                    fontSize = 16.sp,
                    color = ExtraLightGrey
                )

                Spacer(modifier = Modifier.height(40.dp))

                FillButton(
                    onClickAction = {
                        viewModel.setEmailError(email.isEmpty())
                        viewModel.setPwdError((pwd.isEmpty() || pwd.length != 8))

                        if (!emailError && !pwdError)
                            navController.navigate("home")
                    },
                    horizontalArrangement = Arrangement.Center,
                    background = Red,
                    contentColor = White
                ) {
                    BoldText(
                        text = "Entrar",
                        fontSize = 22.sp,
                    )
                }
            }
        }
    }
}