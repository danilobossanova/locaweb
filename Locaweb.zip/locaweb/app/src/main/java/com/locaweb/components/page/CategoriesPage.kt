package com.locaweb.components.page

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.locaweb.R
import com.locaweb.components.email.Category
import com.locaweb.components.layout.Footer
import com.locaweb.components.layout.Header
import com.locaweb.components.text.PageTitle
import com.locaweb.ui.theme.DarkGrey

@Composable
fun CategoriesPage(navController: NavController)
{
    Box(modifier = Modifier.fillMaxSize())
    {
        Column {
            Header(navController)
            PageTitle(text = "Categorias")
            Spacer(modifier = Modifier.height(20.dp))

            Category(icon = R.drawable.file, name = "Rascunhos")
            Category(icon = R.drawable.spam, name = "Spam")
            Category(icon = R.drawable.trash, name = "Lixo")
        }
        Footer(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(DarkGrey),
            active = 3,
            navController = navController
        )
    }
}