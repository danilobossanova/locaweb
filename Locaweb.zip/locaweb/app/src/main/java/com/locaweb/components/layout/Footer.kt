package com.locaweb.components.layout

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.locaweb.R
import com.locaweb.components.text.BoldText
import com.locaweb.components.text.RegularText
import com.locaweb.ui.theme.MediumGrey
import com.locaweb.ui.theme.Red
import com.locaweb.ui.theme.White

@Composable
fun Footer(modifier: Modifier, active: Int, navController: NavController)
{
    Column(
        modifier = modifier
    ) {
        Divider(
            modifier = Modifier
                .height(1.dp)
                .fillMaxWidth(), color = White
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
        ) {
            Button(
                onClick = { navController.navigate("home") },
                modifier = Modifier
                    .weight(1f)
                    .padding(0.dp),
                contentPadding = PaddingValues(0.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (active == 1) MediumGrey else Color.Transparent
                )
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(7.dp))
                    Icon(
                        painter = painterResource(R.drawable.email),
                        contentDescription = "Recebidos",
                        modifier = Modifier.size(27.dp),
                        tint = if (active == 1) Red else White
                    )
                    if (active == 1)
                    {
                        BoldText(text = "Recebidos", fontSize = 14.sp)
                    }
                    else
                    {
                        RegularText(text = "Recebidos", fontSize = 14.sp)
                    }

                    Spacer(modifier = Modifier.height(7.dp))
                }
            }
            Spacer(modifier = Modifier.width(7.dp))
            Button(
                onClick = { navController.navigate("sentEmails") },
                modifier = Modifier
                    .weight(1f)
                    .padding(0.dp),
                contentPadding = PaddingValues(0.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (active == 2) MediumGrey else Color.Transparent
                )
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(7.dp))
                    Icon(
                        painter = painterResource(R.drawable.sent),
                        contentDescription = "Enviados",
                        modifier = Modifier.size(27.dp),
                        tint = if (active == 2) Red else White
                    )
                    if (active == 2)
                    {
                        BoldText(text = "Enviados", fontSize = 14.sp)
                    }
                    else
                    {
                        RegularText(text = "Enviados", fontSize = 14.sp)
                    }
                    Spacer(modifier = Modifier.height(7.dp))
                }
            }
            Spacer(modifier = Modifier.width(7.dp))
            Button(
                onClick = { navController.navigate("categories") },
                modifier = Modifier
                    .weight(1f)
                    .padding(0.dp),
                contentPadding = PaddingValues(0.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (active == 3) MediumGrey else Color.Transparent
                )
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(7.dp))
                    Icon(
                        painter = painterResource(R.drawable.categories),
                        contentDescription = "Categorias",
                        modifier = Modifier.size(27.dp),
                        tint = if (active == 3) Red else White
                    )
                    if (active == 3)
                    {
                        BoldText(text = "Categorias", fontSize = 14.sp)
                    }
                    else
                    {
                        RegularText(text = "Categorias", fontSize = 14.sp)
                    }
                    Spacer(modifier = Modifier.height(7.dp))
                }
            }
            Spacer(modifier = Modifier.width(7.dp))
            Button(
                onClick = { navController.navigate("calendar") },
                modifier = Modifier
                    .weight(1f)
                    .padding(0.dp),
                contentPadding = PaddingValues(0.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (active == 4) MediumGrey else Color.Transparent
                )
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(7.dp))
                    Icon(
                        painter = painterResource(R.drawable.calendar),
                        contentDescription = "Calendário",
                        modifier = Modifier.size(27.dp),
                        tint = if (active == 4) Red else White
                    )
                    if (active == 4)
                    {
                        BoldText(text = "Calendário", fontSize = 14.sp)
                    }
                    else
                    {
                        RegularText(text = "Calendário", fontSize = 14.sp)
                    }
                    Spacer(modifier = Modifier.height(7.dp))
                }
            }
        }
    }
}