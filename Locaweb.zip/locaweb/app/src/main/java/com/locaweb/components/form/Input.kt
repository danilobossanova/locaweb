package com.locaweb.components.form

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.locaweb.ui.theme.Red
import com.locaweb.ui.theme.White
import com.locaweb.ui.theme.RobotoRegular

@Composable
fun Input(
    name: String,
    required: Boolean = true,
    enabled: Boolean = true,
    keyboardOptions: KeyboardOptions,
    placeholder: String,
    value: String,
    onValueChange: (newValue: String) -> Unit,
    mask: String? = null,
    visualTransformation: VisualTransformation? = null,
    error: Boolean = false,
    maxLines: Int = 1,
    color: Color = White
) {
    val transformation = if (mask != null && visualTransformation == null) {

        val offsetMapping = createOffsetMapping(mask)

        VisualTransformation { text ->
            val transformedText = applyMask(mask, text.text)

            TransformedText(
                text = AnnotatedString(transformedText),
                offsetMapping = offsetMapping
            )
        }

    } else {
        VisualTransformation.None
    }

    OutlinedTextField(
        value = value,
        singleLine = maxLines == 1,
        isError = error,
        onValueChange = {
            onValueChange(it)
        },
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().wrapContentHeight(),
        keyboardOptions = keyboardOptions,
        label = {
            Row(verticalAlignment = Alignment.Top) {
                Text(text = name, fontSize = 16.sp, fontFamily = RobotoRegular)
                if (required)
                {
                    Text(text = "*", color = Red, fontFamily = RobotoRegular)
                }
            }
        },
        shape = RoundedCornerShape(7.dp),
        placeholder = {
            Text(text = placeholder, fontSize = 16.sp, fontFamily = RobotoRegular)
        },
        colors = OutlinedTextFieldDefaults.colors(
            focusedLabelColor = color,
            errorTextColor = Red,
            errorContainerColor = Color(0xFFFFF1F6),
            cursorColor = color,
            focusedTextColor = color,
            unfocusedTextColor = color,
            focusedPlaceholderColor = color,
            unfocusedPlaceholderColor = color,
            unfocusedLabelColor = color,
            unfocusedBorderColor = color,
            focusedBorderColor = color,
        ),
        visualTransformation = visualTransformation ?: transformation,
        minLines = maxLines,
        maxLines = maxLines
    )
}

private fun applyMask(mask: String, text: String): String {
    var index = 0
    val maskedText = StringBuilder()
    for (char in mask) {
        if (index >= text.length) break
        if (char == '#') {
            maskedText.append(text[index])
            index++
        } else {
            maskedText.append(char)
        }
    }
    return maskedText.toString()
}

private fun createOffsetMapping(mask: String): OffsetMapping {
    return object : OffsetMapping {
        override fun originalToTransformed(offset: Int): Int {
            var transformedOffset = offset
            var originalOffset = 0

            mask.forEachIndexed { index, char ->
                if (index >= transformedOffset) return@forEachIndexed
                if (char != '#') transformedOffset++
                if (index < offset && char != '#') originalOffset++
            }
            return transformedOffset
        }

        override fun transformedToOriginal(offset: Int): Int {
            var originalOffset = offset

            mask.forEachIndexed { index, char ->
                if (index >= originalOffset) return@forEachIndexed
                if (char != '#') originalOffset++
            }
            return originalOffset
        }
    }
}