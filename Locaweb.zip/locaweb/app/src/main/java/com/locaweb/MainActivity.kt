package com.locaweb

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.locaweb.components.page.CalendarPage
import com.locaweb.components.page.CategoriesPage
import com.locaweb.components.page.CreateEmailPage
import com.locaweb.components.page.ReceivedEmailPage
import com.locaweb.components.page.HomePage
import com.locaweb.components.page.LoginPage
import com.locaweb.components.page.ScheduledEmailPage
import com.locaweb.components.page.ScheduledEmailsPage
import com.locaweb.components.page.SearchPage
import com.locaweb.components.page.SentEmailPage
import com.locaweb.components.page.SentEmailsPage
import com.locaweb.ui.theme.LocawebTheme
import com.locaweb.ui.theme.DarkGrey
import com.locaweb.viewModel.CreateEmailViewModel
import com.locaweb.viewModel.LoginViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LocawebTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkGrey
                ) {
                    val navController = rememberNavController()
                    NavHost(
                        navController = navController,
                        startDestination = "login"
                    ) {
                        composable(route = "login") { LoginPage(navController, LoginViewModel()) }
                        composable(route = "home") { HomePage(navController) }
                        composable(route = "sentEmails") { SentEmailsPage(navController) }
                        composable(route = "categories") { CategoriesPage(navController) }
                        composable(route = "receivedEmail") { ReceivedEmailPage(navController) }
                        composable(route = "sentEmail") { SentEmailPage(navController) }
                        composable(route = "createEmail") { CreateEmailPage(navController, CreateEmailViewModel()) }
                        composable(route = "calendar") { CalendarPage(navController) }
                        composable(
                            route="scheduledEmails/{day}",
                            arguments = listOf(navArgument("day") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val day = backStackEntry.arguments?.getString("day")
                            ScheduledEmailsPage(navController, day)
                        }
                        composable(route = "scheduledEmail") { ScheduledEmailPage(navController) }
                        composable(route = "search") { SearchPage(navController) }
                    }
                }
            }
        }
    }
}