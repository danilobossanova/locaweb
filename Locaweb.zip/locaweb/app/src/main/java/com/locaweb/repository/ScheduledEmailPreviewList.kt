package com.locaweb.repository

import com.locaweb.R
import com.locaweb.model.ScheduledEmailPreview

fun getAllScheduledEmailPreview(): List<ScheduledEmailPreview> {
    return listOf(
        ScheduledEmailPreview(
            photo = R.drawable.person7,
            sender = "Cumpadre Washington",
            subject = "Tô precisando de ajuda Compadre",
            text = "Vou chamar a rapaziada e a equipe...",
            time = "12:35"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person8,
            sender = "Joãozinho",
            subject = "Encontro de amanhã",
            text = "Vamos nos encontrar no mesmo lugar de sempre?",
            time = "14:50"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person9,
            sender = "Mariazinha",
            subject = "Documentos importantes",
            text = "Preciso que revise os documentos até o final do dia.",
            time = "16:10"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person7,
            sender = "Carlos Alberto",
            subject = "Reunião de equipe",
            text = "Não se esqueça da reunião de amanhã às 10h.",
            time = "09:00"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person8,
            sender = "Ana Paula",
            subject = "Projeto final",
            text = "O projeto está quase pronto, falta apenas revisar alguns...",
            time = "11:45"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person9,
            sender = "Lucas Silva",
            subject = "Relatório mensal",
            text = "Enviei o relatório mensal para revisão, por favor, confira.",
            time = "13:30"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person7,
            sender = "Mariana Oliveira",
            subject = "Convite para evento",
            text = "Você está convidado para o nosso evento de final de ano.",
            time = "15:20"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person8,
            sender = "Pedro Santos",
            subject = "Atualização do sistema",
            text = "O sistema será atualizado na próxima semana.",
            time = "17:45"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person9,
            sender = "Julia Pereira",
            subject = "Parceria comercial",
            text = "Estamos interessados em uma parceria comercial com sua empresa.",
            time = "08:15"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person7,
            sender = "Fernanda Costa",
            subject = "Treinamento",
            text = "O treinamento será realizado na sexta-feira às 14h.",
            time = "10:50"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person8,
            sender = "Ricardo Almeida",
            subject = "Reunião de planejamento",
            text = "Vamos discutir as estratégias para o próximo trimestre.",
            time = "12:30"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person9,
            sender = "Paula Souza",
            subject = "Novo projeto",
            text = "Tenho uma proposta de um novo projeto para discutirmos.",
            time = "14:00"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person7,
            sender = "André Ribeiro",
            subject = "Relatório semanal",
            text = "Enviei o relatório semanal, por favor, revise e me dê um feedback.",
            time = "16:25"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person8,
            sender = "Beatriz Gomes",
            subject = "Agenda de compromissos",
            text = "Segue a agenda de compromissos para a próxima semana.",
            time = "18:10"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person9,
            sender = "José Carvalho",
            subject = "Feedback do cliente",
            text = "Recebemos um feedback positivo do cliente sobre o projeto.",
            time = "08:45"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person7,
            sender = "Carla Dias",
            subject = "Planejamento de férias",
            text = "Precisamos discutir o planejamento das férias da equipe.",
            time = "10:15"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person8,
            sender = "Eduardo Martins",
            subject = "Atualização de projeto",
            text = "O projeto foi atualizado, por favor, confira as alterações.",
            time = "13:05"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person9,
            sender = "Larissa Ferreira",
            subject = "Reunião de feedback",
            text = "A reunião de feedback será na terça-feira às 11h.",
            time = "15:50"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person7,
            sender = "Fábio Lima",
            subject = "Documentação técnica",
            text = "A documentação técnica foi enviada para revisão.",
            time = "17:20"
        ),
        ScheduledEmailPreview(
            photo = R.drawable.person8,
            sender = "Sofia Rocha",
            subject = "Convite para palestra",
            text = "Gostaríamos de convidá-lo para nossa palestra sobre inovação.",
            time = "19:00"
        )
    )
}