package com.locaweb.components.page

import android.widget.Space
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.locaweb.components.button.FillButton
import com.locaweb.components.form.Form
import com.locaweb.components.form.Input
import com.locaweb.components.layout.Footer
import com.locaweb.components.text.BoldText
import com.locaweb.ui.theme.DarkGrey
import com.locaweb.ui.theme.Red
import com.locaweb.ui.theme.White

@Composable
fun SearchPage(navController: NavController)
{
    Box(modifier = Modifier
        .fillMaxSize()
        .background(White))
    {
        Column(modifier = Modifier.padding(10.dp)) {
            Form {
                Input(
                    name = "Buscar emails",
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text
                    ),
                    placeholder = "Digite aqui",
                    value = "",
                    color = DarkGrey,
                    onValueChange = {
                    },
                    required = false
                )

                Spacer(modifier = Modifier.height(0.dp))
                BoldText(
                    text = "Filtros",
                    fontSize = 20.sp,
                    color = DarkGrey,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Input(
                    name = "Para",
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Email
                    ),
                    placeholder = "Destinatário",
                    value = "",
                    color = DarkGrey,
                    onValueChange = {
                    },
                    required = false
                )
                Input(
                    name = "Assunto",
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text
                    ),
                    placeholder = "Digite o assunto",
                    value = "",
                    color = DarkGrey,
                    onValueChange = {
                    },
                    required = false
                )
                Input(
                    name = "Contém as palavras",
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text
                    ),
                    placeholder = "Digite as palavras",
                    value = "",
                    color = DarkGrey,
                    onValueChange = {
                    },
                    required = false
                )
                Input(
                    name = "Não tem as palavras",
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text
                    ),
                    placeholder = "Digite as palavras",
                    value = "",
                    color = DarkGrey,
                    onValueChange = {
                    },
                    required = false
                )
                Input(
                    name = "Data",
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text
                    ),
                    placeholder = "Digite a data",
                    value = "",
                    color = DarkGrey,
                    onValueChange = {
                    },
                    required = false
                )
                Spacer(modifier = Modifier.height(10.dp))
                FillButton(
                    onClickAction = {
                        navController.navigate("home")
                    },
                    horizontalArrangement = Arrangement.Center,
                    background = Red,
                    contentColor = White
                ) {
                    BoldText(
                        text = "Pesquisar",
                        fontSize = 22.sp,
                    )
                }
            }
        }
        Footer(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(DarkGrey),
            active = 0,
            navController = navController
        )
    }
}