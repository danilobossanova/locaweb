package com.locaweb.components.text

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Divider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.locaweb.ui.theme.DarkGrey
import com.locaweb.ui.theme.White

@Composable
fun PageTitle(text: String)
{
    Column(modifier = Modifier.background(DarkGrey)) {
        BoldText(
            text = text,
            fontSize = 19.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
        )
        Divider(
            modifier = Modifier
                .height(1.dp)
                .fillMaxWidth(), color = White
        )
    }
}