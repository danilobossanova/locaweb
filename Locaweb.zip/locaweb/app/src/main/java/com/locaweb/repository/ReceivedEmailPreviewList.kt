package com.locaweb.repository

import com.locaweb.R
import com.locaweb.model.ReceivedEmailPreview

fun getAllReceivedEmailPreview(): List<ReceivedEmailPreview>
{
    return listOf(
        ReceivedEmailPreview(
            photo = R.drawable.person1,
            sender = "Manu Gavassi",
            subject = "Contratei uma pessoa proativa",
            text = "Devo contratá-la?",
            time = "12:35",
            viewed = true
        ),
        ReceivedEmailPreview(
            photo = R.drawable.person2,
            sender = "Gustavo Lopes",
            subject = "Não aguento meu trabalho",
            text = "Devolve meu dinheiro",
            time = "12:10",
            pinned = true
        ),
        ReceivedEmailPreview(
            photo = R.drawable.person3,
            sender = "Prefeito de Monte Sião",
            subject = "Não gosto dessa cidade",
            text = "Abaixo segue e a planilha...",
            time = "9:30"
        ),
        ReceivedEmailPreview(
            photo = R.drawable.person1,
            sender = "Ana Maria",
            subject = "Convite para evento",
            text = "Você está convidado para o nosso evento anual...",
            time = "11:45",
            viewed = true
        ),
        ReceivedEmailPreview(
            photo = R.drawable.person2,
            sender = "João Pedro",
            subject = "Reunião de sexta-feira",
            text = "Lembrete da reunião às 14h...",
            time = "10:50",
            viewed = true
        ),
        ReceivedEmailPreview(
            photo = R.drawable.person3,
            sender = "Maria Clara",
            subject = "Atualização do projeto",
            text = "Precisamos discutir a atualização do projeto...",
            time = "10:05"
        ),
        ReceivedEmailPreview(
            photo = R.drawable.person1,
            sender = "Lucas Silva",
            subject = "Pedido de feedback",
            text = "Gostaria de receber seu feedback sobre o relatório...",
            time = "09:50",
            pinned = true,
            viewed = true
        ),
        ReceivedEmailPreview(
            photo = R.drawable.person2,
            sender = "Beatriz Santos",
            subject = "Férias aprovadas",
            text = "Suas férias foram aprovadas...",
            time = "08:30"
        ),
        ReceivedEmailPreview(
            photo = R.drawable.person3,
            sender = "Carlos Almeida",
            subject = "Relatório de vendas",
            text = "Segue em anexo o relatório de vendas do último mês...",
            time = "07:45"
        )
    )
}