package com.locaweb.components.text

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import com.locaweb.ui.theme.RobotoRegular
import com.locaweb.ui.theme.White

@Composable
fun RegularText(
    text: String,
    fontSize: TextUnit,
    color: Color = White,
    modifier: Modifier = Modifier,
    textAlign: TextAlign = TextAlign.Left
) {
    Text(
        text = text,
        fontFamily = RobotoRegular,
        fontSize = fontSize,
        color = color,
        modifier = modifier,
        textAlign = textAlign
    )
}