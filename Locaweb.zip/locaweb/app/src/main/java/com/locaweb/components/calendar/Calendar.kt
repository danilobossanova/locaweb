package com.locaweb.components.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.locaweb.R
import com.locaweb.components.text.BlackText
import com.locaweb.components.text.BoldText
import com.locaweb.components.text.RegularText
import com.locaweb.ui.theme.Aqua
import com.locaweb.ui.theme.MediumGrey
import com.locaweb.ui.theme.Red

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Calendar( navController: NavController)
{
    Column(
        modifier = Modifier.padding(start = 10.dp, end = 10.dp, bottom = 10.dp)
    ) {
        Row {
            BoldText(
                text = "Junho",
                fontSize = 20.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
        Row {
            for (day in listOf("Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"))
            {
                BoldText(
                    text = day,
                    fontSize = 17.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .weight(1f)
                        .padding(bottom = 10.dp)
                )
            }
        }
        FlowRow(
            maxItemsInEachRow = 7,
            verticalArrangement = Arrangement.spacedBy(2.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {

            val daysAndQtyEmails = mapOf(
                12 to 35,
                15 to 13,
                20 to 20,
                25 to 10
            )

            for (i in 1..35)
            {
                if (i <= 31)
                {
                    Box(
                        modifier = Modifier
                            .height(80.dp)
                            .weight(1f)
                            .background(MediumGrey)
                    ) {
                        Surface(
                            onClick = {
                                if (daysAndQtyEmails.containsKey(i))
                                {
                                    navController.navigate("scheduledEmails/$i")
                                }
                            },
                            color = Color.Transparent,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Spacer(modifier = Modifier.height(4.dp))

                                if (i == 11)
                                {
                                    Surface(
                                        shape = CircleShape,
                                        color = Color.White,
                                    ) {
                                        Box(modifier = Modifier.padding(3.dp))
                                        {
                                            BlackText(text = "$i", fontSize = 15.sp, color = Color.DarkGray)
                                        }
                                    }
                                }
                                else
                                {
                                    RegularText(text = "$i", fontSize = 15.sp, modifier = Modifier.padding(3.dp))
                                }
                                
                                Spacer(modifier = Modifier.height(10.dp))
                                if (daysAndQtyEmails.containsKey(i))
                                {
                                    Surface(
                                        shape = CircleShape,
                                        color = Red
                                    ) {
                                        Box(modifier = Modifier.padding(3.dp))
                                        {
                                            val emailQty = daysAndQtyEmails[i]
                                            BlackText(
                                                text = "$emailQty",
                                                fontSize = 15.sp,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    Box(modifier = Modifier.weight(1f))
                }
            }
        }
        Spacer(modifier = Modifier.height(15.dp))
        Row(
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = { /*TODO*/ },
                colors = ButtonDefaults.buttonColors(containerColor = MediumGrey),
                shape = RoundedCornerShape(100.dp)
            ) {
                Icon(
                    painter = painterResource(R.drawable.left_chevron),
                    contentDescription = "Voltar mês",
                    modifier = Modifier.size(35.dp),
                    tint = Aqua
                )
            }
            Spacer(modifier = Modifier.width(15.dp))
            Button(
                onClick = { /*TODO*/ },
                colors = ButtonDefaults.buttonColors(containerColor = MediumGrey),
                shape = RoundedCornerShape(100.dp)
            ) {
                Icon(
                    painter = painterResource(R.drawable.right_chevron),
                    contentDescription = "Avançar mês",
                    modifier = Modifier.size(35.dp),
                    tint = Aqua
                )
            }
        }
    }
}