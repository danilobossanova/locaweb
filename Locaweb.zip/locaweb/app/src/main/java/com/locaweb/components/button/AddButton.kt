package com.locaweb.components.button

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.locaweb.R
import com.locaweb.components.text.BlackText
import com.locaweb.ui.theme.Red
import com.locaweb.ui.theme.White

@Composable
fun AddButton(onClickAction: () -> Unit, modifier: Modifier)
{
    Button(
        onClick = { onClickAction() },
        shape = CircleShape,
        modifier = modifier,
        contentPadding = PaddingValues(20.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = White)
    ) {
        Icon(
            painter = painterResource(R.drawable.plus),
            contentDescription = "Enviar email",
            modifier = Modifier.size(27.dp),
            tint = White
        )
    }
}