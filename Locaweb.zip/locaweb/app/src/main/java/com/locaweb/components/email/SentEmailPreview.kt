package com.locaweb.components.email

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.locaweb.R
import com.locaweb.components.image.PersonPhoto
import com.locaweb.components.text.BlackText
import com.locaweb.components.text.BoldText
import com.locaweb.components.text.RegularText
import com.locaweb.model.SentEmailPreview
import com.locaweb.ui.theme.Aqua
import com.locaweb.ui.theme.White

@Composable
fun SentEmailPreview(
    sentEmailPreview: SentEmailPreview,
    onClickAction: () -> Unit
) {
    Button(
        onClick = { onClickAction() },
        contentPadding = PaddingValues(0.dp),
        shape = RoundedCornerShape(0.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 15.dp, bottom = 15.dp, end = 10.dp)
                .height(IntrinsicSize.Max)
        ) {
            Column(
                modifier = Modifier
                    .weight(.02f)
                    .fillMaxHeight()
            ) {
            }
            Column(
                modifier = Modifier
                    .weight(.24f)
                    .fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                PersonPhoto(photo = sentEmailPreview.photo)
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                BlackText(text = sentEmailPreview.sender, fontSize = 19.sp)
                Spacer(modifier = Modifier.height(5.dp))
                BoldText(text = sentEmailPreview.subject, fontSize = 17.sp)
                RegularText(text = sentEmailPreview.text, fontSize = 15.sp)
            }
            Column(
                modifier = Modifier
                    .weight(.2f)
                    .fillMaxHeight(),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                RegularText(text = sentEmailPreview.time, fontSize = 16.sp)

                Icon(
                    painter = painterResource(id = R.drawable.double_check),
                    contentDescription = if (!sentEmailPreview.viewed) "Não visualizado" else "Visualizado",
                    modifier = Modifier.size(25.dp),
                    tint = if (!sentEmailPreview.viewed) White else Aqua
                )
            }
        }
    }
}